package com.fahmi.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

private data class Trigger(var label: String, var x: Float, var y: Float, var radius: Float, var mode: String = "Tap", var interval: Int = 100, var duration: Int = 50)

class MainActivity : Activity() {
    private lateinit var board: MappingBoard
    private lateinit var info: TextView
    private val triggers = mutableListOf<Trigger>()
    private var selected = 0
    private val modes = arrayOf("Tap", "Repeat Tap", "Double Tap", "Release Tap")
    private var syncingMode = false
    private lateinit var modeSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        if (triggers.isEmpty()) {
            triggers += Trigger("T1", .30f, .55f, 42f)
            triggers += Trigger("T2", .70f, .55f, 42f)
            triggers += Trigger("T3", .50f, .78f, 42f)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 24, 18, 18)
            setBackgroundColor(0xFF07120F.toInt())
        }
        val header = TextView(this).apply {
            text = "F   FAHMI\nTRIGGER MAPPING"
            textSize = 21f; setTextColor(0xFF35E0AA.toInt()); gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 8, 8, 16)
        }
        root.addView(header)
        info = TextView(this).apply { text = "Drag a trigger to move it • Drag its small corner handle to resize"; textSize = 12f; setTextColor(0xFFB6C8C1.toInt()); setPadding(4, 4, 4, 12) }
        root.addView(info)
        board = MappingBoard()
        root.addView(board, LinearLayout.LayoutParams(-1, 0, 1f))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        addButton(row1, "＋ Add trigger") { addTrigger() }
        addButton(row1, "− Remove") { if (triggers.size > 1) { triggers.removeAt(selected.coerceIn(0, triggers.lastIndex)); selected = 0; board.invalidate(); save() } }
        root.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        modeSpinner = Spinner(this)
        modeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes)
        modeSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncingMode && triggers.isNotEmpty()) { triggers[selected.coerceIn(0, triggers.lastIndex)].mode = modes[position]; save(); board.invalidate() }
            }
        }
        row2.addView(TextView(this).apply { text = "Mode"; setTextColor(-1); setPadding(4, 8, 12, 8) })
        row2.addView(modeSpinner, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row2)

        val row3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        addButton(row3, "Interval −") { editNumber(-10, true) }
        addButton(row3, "Interval +") { editNumber(10, true) }
        addButton(row3, "Duration −") { editNumber(-10, false) }
        addButton(row3, "Duration +") { editNumber(10, false) }
        root.addView(row3)
        val save = Button(this).apply { text = "SAVE MAPPING"; setOnClickListener { save(); Toast.makeText(this@MainActivity, "Mapping saved", Toast.LENGTH_SHORT).show() } }
        root.addView(save)
        setContentView(root)
    }

    private fun addButton(parent: LinearLayout, text: String, action: () -> Unit) {
        parent.addView(Button(this).apply { this.text = text; textSize = 10f; setOnClickListener { action() } }, LinearLayout.LayoutParams(0, -2, 1f))
    }
    private fun addTrigger() {
        var n = 1
        val used = triggers.map { it.label }.toSet()
        while ("T$n" in used) n++
        triggers += Trigger("T$n", .5f, .5f, 42f)
        selected = triggers.lastIndex
        info.text = "${triggers[selected].label} selected • Tap"
        syncingMode = true
        modeSpinner.setSelection(0)
        syncingMode = false
        board.invalidate()
        save()
    }
    private fun editNumber(delta: Int, interval: Boolean) {
        if (triggers.isEmpty()) return
        val t = triggers[selected.coerceIn(0, triggers.lastIndex)]
        if (interval) t.interval = max(1, t.interval + delta) else t.duration = max(1, t.duration + delta)
        info.text = "${t.label} • ${t.mode} • interval ${t.interval} ms • duration ${t.duration} ms"
        save()
    }
    private fun save() {
        val a = JSONArray(); triggers.forEach { t -> a.put(JSONObject().put("label", t.label).put("x", t.x).put("y", t.y).put("radius", t.radius).put("mode", t.mode).put("interval", t.interval).put("duration", t.duration)) }
        getSharedPreferences("fahmi", MODE_PRIVATE).edit().putString("mapping", a.toString()).apply()
    }
    private fun load() {
        try { val a = JSONArray(getSharedPreferences("fahmi", MODE_PRIVATE).getString("mapping", "[]")); for (i in 0 until a.length()) { val o = a.getJSONObject(i); triggers += Trigger(o.optString("label", "T${i+1}"), o.optDouble("x", .5).toFloat(), o.optDouble("y", .5).toFloat(), o.optDouble("radius", 42.0).toFloat(), o.optString("mode", "Tap"), o.optInt("interval", 100), o.optInt("duration", 50)) } } catch (_: Exception) { }
    }

    private inner class MappingBoard : View(this@MainActivity) {
        private val fill = Paint(3).apply { color = 0x6635E0AA; style = Paint.Style.FILL }
        private val stroke = Paint(3).apply { color = 0xFF35E0AA.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f }
        private val text = Paint(3).apply { color = -1; textSize = 28f; textAlign = Paint.Align.CENTER }
        private val handle = Paint(3).apply { color = 0xFFFFD166.toInt(); style = Paint.Style.FILL }
        private var active = -1; private var resizing = false; private var downX = 0f; private var downY = 0f
        override fun onDraw(c: Canvas) {
            super.onDraw(c); c.drawColor(0xFF10221C.toInt())
            val grid = Paint(1).apply { color = 0x2235E0AA; strokeWidth = 1f }
            for (i in 1..9) { c.drawLine(width*i/10f, 0f, width*i/10f, height.toFloat(), grid); c.drawLine(0f, height*i/10f, width.toFloat(), height*i/10f, grid) }
            triggers.forEachIndexed { i, t ->
                val x = t.x * width; val y = t.y * height
                val r = t.radius
                c.drawCircle(x, y, r, fill); c.drawCircle(x, y, r, stroke)
                if (i == selected) { c.drawCircle(x, y, r+7, stroke); c.drawCircle(x+r*.72f, y+r*.72f, 11f, handle) }
                c.drawText(t.label, x, y+9f, text)
            }
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX=e.x; downY=e.y; active=-1; resizing=false
                    for (i in triggers.indices.reversed()) { val t=triggers[i]; val x=t.x*width; val y=t.y*height; val dx=e.x-x; val dy=e.y-y
                        if (i==selected && dx > t.radius*.45f && dy > t.radius*.45f && kotlin.math.hypot(dx.toDouble(),dy.toDouble()) < t.radius*1.15) { active=i; resizing=true; break }
                        if (kotlin.math.hypot(dx.toDouble(),dy.toDouble()) <= t.radius) { active=i; break }
                    }
                    if (active>=0) {
                        selected=active
                        info.text="${triggers[active].label} selected • ${triggers[active].mode} • interval ${triggers[active].interval} ms • duration ${triggers[active].duration} ms"
                        syncingMode = true
                        modeSpinner.setSelection(modes.indexOf(triggers[active].mode).coerceAtLeast(0))
                        syncingMode = false
                        invalidate()
                        return true
                    }
                }
                MotionEvent.ACTION_MOVE -> if (active>=0) {
                    val t=triggers[active]
                    if (resizing) t.radius=(t.radius + (e.x-downX + e.y-downY)*.25f).coerceIn(22f, min(width,height)*.25f)
                    else { t.x=(e.x/width).coerceIn(0f,1f); t.y=(e.y/height).coerceIn(0f,1f) }
                    downX=e.x; downY=e.y; invalidate(); return true
                }
                MotionEvent.ACTION_UP -> if (active>=0) { save(); return true }
            }
            return true
        }
    }
}
