# Fahmi — Android trigger-mapping editor

Independent Kotlin/Android implementation of a trigger mapping **editor prototype**.

## Included
- Fahmi-branded dark-green mapping canvas
- Add and remove mapping markers
- Drag markers to reposition them
- Drag the selected marker's corner handle to resize it
- Tap, Repeat Tap, Double Tap, and Release Tap modes
- Per-marker interval and duration controls
- Local persistence of marker layout and settings

## Not included yet
- System-wide floating overlay over other apps
- In-game touch injection / automated tapping
- Exact reproduction of Nebula Touch's proprietary UI or internals
- Import of Nebula Touch account, credit, or premium data

There is no credit counter or premium purchase screen in this independent project. It does not crack or patch the original Nebula Touch APK.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Allow Gradle sync to complete.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

You can also push the project to GitHub. `.github/workflows/android.yml` builds a debug APK on push or manual dispatch.

## Requirements
- JDK 17; Android Gradle Plugin 8.7.3; Kotlin 2.0.21; Android SDK 35
- Minimum Android version: Android 8.0 (API 26)

## Controls
- Tap a marker to select it.
- Drag inside a marker to move it.
- Drag the small yellow handle on the selected marker to resize it.
- Use the controls below the canvas to set its trigger mode and timing.
- Press **SAVE MAPPING** to save. Layouts are also saved automatically after edits.
