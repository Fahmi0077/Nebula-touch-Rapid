package com.nebula.rapidtouch

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.ViewGroup

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(36), dp(24), dp(24))
            setBackgroundColor(Color.rgb(9, 9, 20))
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(8))
        }
        val title = label("NEBULA RAPID TOUCH", 24f)
        title.setTextColor(Color.rgb(177, 130, 255))
        layout.addView(title)
        layout.addView(label("Hold the floating trigger to repeat taps at one fixed screen point. Release to stop."))
        layout.addView(label("Tap target X coordinate (pixels)"))
        val xField = EditText(this).apply {
            setSingleLine(true); inputType = 2
            setText(prefs.getInt("x", resources.displayMetrics.widthPixels / 2).toString())
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); hint = "X"
        }
        layout.addView(xField, ViewGroup.LayoutParams(-1, dp(52)))
        layout.addView(label("Tap target Y coordinate (pixels)"))
        val yField = EditText(this).apply {
            setSingleLine(true); inputType = 2
            setText(prefs.getInt("y", resources.displayMetrics.heightPixels / 2).toString())
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); hint = "Y"
        }
        layout.addView(yField, ViewGroup.LayoutParams(-1, dp(52)))
        val save = Button(this).apply {
            text = "SAVE TAP POSITION"
            setOnClickListener {
                val x = xField.text.toString().toIntOrNull()
                val y = yField.text.toString().toIntOrNull()
                if (x != null && y != null && x >= 0 && y >= 0) {
                    prefs.edit().putInt("x", x).putInt("y", y).apply()
                    text = "SAVED"
                } else text = "ENTER VALID PIXEL VALUES"
            }
        }
        layout.addView(save)
        val overlay = Button(this).apply {
            text = "1  •  ALLOW DISPLAY OVER OTHER APPS"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        layout.addView(overlay)
        val access = Button(this).apply {
            text = "2  •  ENABLE ACCESSIBILITY SERVICE"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        layout.addView(access)
        layout.addView(label("After granting both permissions, return here. The floating HOLD button appears while the accessibility service is enabled.", 13f))
        setContentView(layout)
    }
}
