# Nebula Rapid Touch (Android 16)

A starter Android Studio project for a user-controlled, single-coordinate hold-to-repeat tap overlay.

## Build
1. Open this folder in Android Studio (a recent version with Android SDK Platform 36).
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Setup on the phone
1. Install the APK.
2. Open the app and grant **Display over other apps**.
3. In Android Accessibility settings, enable **Nebula Rapid Touch**.
4. Return to the app. The floating HOLD TAP control should appear.
5. Enter the target screen pixel coordinates and save. The default is the screen center.
6. Open a game or app and press-and-hold the floating control. Release to stop.

## Important limitations
- Android accessibility gesture injection is controlled by the OS. It does not guarantee a particular taps-per-second rate; this implementation repeats as soon as each injected tap completes.
- Some games block or disallow automated input. Check the game's rules before using it.
- Pixel coordinates are display coordinates; navigation bars, display scaling, rotation, and cutouts can affect the target position.
- If you grant overlay permission after enabling the accessibility service, toggle the service off and on again so the overlay is created.
- The accessibility service does not request permission to read window content. It only requests gesture capability.
- Use only on apps/games where automated tapping is permitted.
